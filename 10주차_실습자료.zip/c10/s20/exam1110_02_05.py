import random
import matplotlib.pyplot as plt

data_x = []
data_y = []
data_size = []

# data_x, data_y, data_size 의 값을 랜덤하게(임의로) 100개를 생성해 주세요.
# 램덤의 범위는 1 ~ 100

for i in range(100):
    data_x.append( random.randint(1, 100) )
    data_y.append( random.randint(1, 100) )
    data_size.append( random.randint(1, 1000) )

data_color = range(len(data_x))

plt.scatter(data_x, data_y
            , s=data_size
            , c=data_color
            , cmap='jet'
            , alpha=0.6
            )
plt.colorbar()
plt.show()

