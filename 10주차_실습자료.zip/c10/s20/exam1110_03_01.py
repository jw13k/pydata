import math

import matplotlib.pyplot as plt

from c10.s10.exam1110_data import get_data

filename = '../s10/2022_연령별인구현황.csv'
gender = '남성'
search_text = '전국'
data_male = get_data(filename, gender, search_text)
print(data_male)

gender = '여성'
data_female = get_data(filename, gender, search_text)
print(data_female)

data_len = len(data_male)
data_size = []

for i in range(data_len):
    data_size.append( math.sqrt(data_male[i] + data_female[i]) )

plt.scatter(data_male, data_female
            , s=data_size
            , c=range(data_len)
            , cmap='jet'
            , alpha=0.6
            )
plt.colorbar()

line_x = range(max(data_male))
plt.plot(line_x, line_x, c='green')

plt.show()



