import matplotlib.pyplot as plt

data_x = [1, 2, 3, 4]
data_y = [10, 20, 50, 30]
data_size = [10, 50, 25, 1000]
#data_color = ['#ff0000', '#00ff00', '#0000ff', '#ff00ff']
data_color = range(len(data_x))

plt.scatter(data_x, data_y
            , s=data_size
            , c=data_color
            , cmap='jet'
            )
plt.colorbar()
plt.show()

