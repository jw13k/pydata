import matplotlib.pyplot as plt

data_x = [1, 2, 3, 4]
data_y = [10, 20, 50, 30]

plt.scatter(data_x, data_y)
plt.show()

