from c12.s1.data_helper import DataHelper
from c12.s1.station import Station

filename = '지하철_시간대별_이용현황.csv'
header_line_count = 2

data_helper = DataHelper(filename, header_line_count)

header = data_helper.get_header()
data = data_helper.get_data()

station_list = []
for time in header[0][4:-1:2]:
    station = Station()
    station.time = time
    station_list.append(station)


index = 0
for station in station_list:
    max_count = 0
    for data_row in data:
        line_name = data_row[1]
        name = data_row[3]
        in_count = int(data_row[4 + 2 * index])
        out_count = int(data_row[5 + 2 * index])
        cur_max_count = in_count + out_count
        if cur_max_count > max_count:
            max_count = cur_max_count
            station.set_data(line_name, name, in_count, out_count)
    index += 1

for station in station_list:
    station.show()












