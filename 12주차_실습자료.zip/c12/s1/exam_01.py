from c12.s1.station import Station

station1 = Station()

#station1.line_name = '1호선'
#station1.name = '구일역'
#station1.in_count = 123
#station1.out_count = 456
#station1.time = '04:00 ~ 04:59:59'

station1.set_data('1호선', '구일역', 123, 456, '04:00 ~ 04:59:59')
station1.show()
