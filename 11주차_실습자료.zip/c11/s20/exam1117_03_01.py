

header = [0,1,2]

header2 = []
header2.append([0,1,2,3])
header2.append([1,2,3,4])

print(header)
print(header2)

print(len(header))
print(len(header2))



