
def add_data(value):
    return value * 2 + 1

list_1 = ['1', '2', '3', '4']
list_2 = []

for i in list_1:
    tmp = int(i)
    tmp2 = add_data(tmp)
    list_2.append(tmp2)

print('step-1 ')
print(list_1)
print(list_2)

list_12 = []
list_12 = list(map(add_data, list(map(int, list_1))))

print('step-2')
print(list_12)