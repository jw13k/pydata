
from exam1117_function import get_file_to_lines, text_full
import matplotlib.pyplot as plt

file_name = '2023년 10월  교통카드 통계자료.csv'
result = get_file_to_lines(file_name)

result_header = result['header']
result_data = result['data']

#### 데이터 가공(문자열을 수치화(int))
for line in result_data:
    for i in range(4, 8):
        line[i] = int(line[i])

max_type = ['유임승차', '유임하차', '무임승차', '무인하차']
colors = ['#ff0000', '#00ff00', '#0000ff', '#ff00ff']
type_len = len(max_type)
max_val = [0] * type_len
max_line = [''] * type_len
max_name = [''] * type_len

plt.rc('font', family='Malgun Gothic')

for data_row in result_data:
    line = data_row[1]  # 노선
    name = data_row[3]  # 역명
    val = data_row[4:8]
    save_file_name = f'./pie/{line}-{name}.png'

    plt.pie(val, labels=max_type, colors=colors, autopct='%1.f%%')
    plt.axis('equal')
    plt.savefig(save_file_name)
    plt.show()

