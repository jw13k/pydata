

text = '가힣나는 자랑스런 택극기 앞에 abcdefg 1234 ㄱㄴㅏ'


text_length = 0

for x in text:
    if ord('가') <= ord(x) <= ord('힣'):
        print(x, ord(x))
        text_length += 2
    else:
        text_length += 1

print(text_length)