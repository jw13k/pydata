import random

import matplotlib.pyplot as plt
import numpy as np

#입력 처리

def get_input_data():
    input_vote = input('총 진행할 투표수를 입력해 주세요.')
    input_vote_count = int(input_vote)

    input_user = input('가상 선거를 진행할 후보자 인원을 입력해 주세요.')
    input_user_count = int(input_user)

    input_user_names = []

    for i in range(input_user_count):
        name = input(f'{i + 1}번째 후보자이름을 입력해 주세요')
        input_user_names.append(name)

    return {
        'vote_count': input_vote_count,
        'user_names': input_user_names
    }
#end-def

input_result = get_input_data()
#input_result = {
#    'vote_count': 120,
#    'user_names': ['이재명', '윤석렬', '안철수', '심상정']
#}
input_vote_count = input_result['vote_count']
input_user_names = input_result['user_names']
input_user_count = len(input_user_names)
input_user_vote_count = [0] * input_user_count

#투표진행
for i in range(input_vote_count):
    vote = random.randint(0, input_user_count - 1)
    rate = (i + 1) / input_vote_count * 100
    input_user_vote_count[vote] += 1
    print(f'\n[투표진행률]: {rate:8.2f}%, {i + 1}명 투표 => {input_user_names[vote]}')
    for j in range(input_user_count):
        user_rate = input_user_vote_count[j] / input_vote_count * 100
        print(f'[기호:{j + 1}] {input_user_names[j]}: {user_rate:8.2f}% (투표수: {input_user_vote_count[j]})')

#당선인 처리
max_vote_count = 0
max_vote_user = ''
for i in range(input_user_count):
    vote_count = input_user_vote_count[i]
    if vote_count > max_vote_count:
        max_vote_count = vote_count
        max_vote_user = input_user_names[i]

print(f'\n[투표결과] 당선인: {max_vote_user}')









