import matplotlib.pyplot as plt
import numpy as np

#4 => 2

value = 16
print(np.sqrt(value))

print('pi:', np.pi)

print('sin(0):', np.sin(0))
print('con(0):', np.cos(0))
print('sin(pi):', np.sin(np.pi))
print('con(pi):', np.cos(np.pi))