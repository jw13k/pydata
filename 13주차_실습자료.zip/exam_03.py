import random

import matplotlib.pyplot as plt
import numpy as np


data = np.random.rand(5)
print(data)
print(type(data))

data2 = []
for i in range(5):
    data2.append(random.randint(0, 10))

print(data2)
print(type(data2))